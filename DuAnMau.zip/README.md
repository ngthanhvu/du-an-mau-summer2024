# Website Bán Hàng

Đây là dự án website bán hàng được phát triển bằng HTML, CSS, JS và PHP.

## Mục đích
Dự án này nhằm xây dựng một website bán hàng đơn giản nhưng đầy đủ các tính năng cần thiết để người dùng có thể xem sản phẩm, đặt hàng và thanh toán trực tuyến.

## Các tính năng chính
Đăng nhập và Đăng ký: Người dùng có thể đăng nhập vào tài khoản của họ hoặc đăng ký một tài khoản mới.

Danh mục sản phẩm: Hiển thị các danh mục sản phẩm và cho phép người dùng duyệt qua các sản phẩm theo danh mục.

Tìm kiếm: Cung cấp chức năng tìm kiếm để người dùng có thể tìm kiếm sản phẩm theo từ khoá.

Giỏ hàng: Cho phép người dùng thêm sản phẩm vào giỏ hàng và quản lý giỏ hàng của mình.

Thanh toán: Cung cấp phương thức thanh toán an toàn và đơn giản để hoàn thành đơn hàng.

## Cài đặt

Clone Repository:

```bash
git clone https://github.com/ngthanhvu/du-an-mau-summer2024.git
```

## Usage

```bash
cd du-an-mau-summer2024
```

## Đóng góp
Nếu bạn muốn đóng góp vào dự án này, hãy làm theo các bước sau:

Fork repository này và clone về máy của bạn.

Tạo một branch mới 
```bash
git checkout -b feature/improvement
```

Commit các thay đổi của bạn
```bash
git commit -am 'Add new feature'
```

Push branch của bạn lên GitHub
```bash
git push origin feature/improvement
```

Tạo một Pull Request mới và mô tả các thay đổi bạn đã thực hiện.

## Tác giả (Auth)

[Thanh vũ](https://facebook.com/thanhvu.user) |
[Nguyễn vũ](https://facebook.com/) |
[Xuân hoài](https://facebook.com/) |
[Văn vũ](https://facebook.com/) |
