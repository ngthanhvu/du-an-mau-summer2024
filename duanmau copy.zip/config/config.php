<?php
#db
define('DB_HOST', 'localhost'); // Thay đổi tên máy chủ cơ sở dữ liệu nếu cần
define('DB_USER', 'thanhvu'); // Thay đổi tên người dùng cơ sở dữ liệu nếu cần
define('DB_PASS', 'Thanhvu@2005'); // Thay đổi mật khẩu cơ sở dữ liệu nếu cần
define('DB_NAME', 'thanhvuduan'); // Thay đổi tên cơ sở dữ liệu của bạn
#vnpay
define("VNPAY_TMN_CODE", "9FHQFJV7");
define("VNPAY_HASH_SECRET", "51CNF74EOXHO7VEELB0W6Z8P6PI8G4MZ");
define("VNPAY_URL", "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html");
define("VNPAY_RETURN_URL", "https://hangsport.online/vnpay_return");
#google login
define('CLIENT_ID', '253811960358-stlaqpojt3iscsdv83nca8k9i6vrq2pl.apps.googleusercontent.com');
define('CLIENT_SECRET', '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');
define('REDIRECT_URI', 'https://hangsport.online/login/google/callback');
?>
